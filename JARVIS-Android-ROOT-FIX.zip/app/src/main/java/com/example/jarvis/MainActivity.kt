package com.example.jarvis

import android.app.Activity
import android.app.AlertDialog
import android.app.AlarmClock
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private val executor = Executors.newSingleThreadExecutor()
    private val bg = Color.rgb(7, 13, 25)
    private val cyan = Color.rgb(64, 210, 255)
    private val white = Color.rgb(225, 240, 250)
    private val requestCodeSpeech = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        tts = TextToSpeech(this, this)
        buildUi()
        addMessage("JARVIS", "Sistem çevrimiçi. Gemini API anahtarını Ayarlar bölümünden ekleyebilirsin.")
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 16)
            setBackgroundColor(bg)
        }
        val header = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 28f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            letterSpacing = 0.22f
        }
        root.addView(header, LinearLayout.LayoutParams(-1, 54))
        val sub = TextView(this).apply {
            text = "PERSONAL AI SYSTEM  •  ONLINE"
            textSize = 10f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
        }
        root.addView(sub, LinearLayout.LayoutParams(-1, 28))

        val reactor = TextView(this).apply {
            text = "◉"
            textSize = 66f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        root.addView(reactor, LinearLayout.LayoutParams(-1, 104))

        val scroll = ScrollView(this)
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 8, 4, 8)
        }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "JARVIS'e bir komut ver..."
            setHintTextColor(Color.GRAY)
            setTextColor(white)
            textSize = 15f
            setSingleLine(false)
            setBackgroundColor(Color.rgb(19, 31, 49))
            setPadding(14, 12, 14, 12)
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(makeButton("GÖNDER") { sendPrompt() }, weightParams())
        row1.addView(makeButton("🎙 KONUŞ") { startListening() }, weightParams())
        root.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(makeButton("ALARM") { setAlarm() }, weightParams())
        row2.addView(makeButton("İNTERNET") { webSearch() }, weightParams())
        row2.addView(makeButton("INSTAGRAM") { shareToInstagram() }, weightParams())
        root.addView(row2)
        root.addView(makeButton("⚙ API AYARLARI") { apiSettings() })
        setContentView(root)
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, 48, 1f).apply {
        setMargins(3, 6, 3, 6)
    }

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 11f
            setTextColor(cyan)
            setBackgroundColor(Color.rgb(18, 39, 59))
            setOnClickListener { action() }
        }
    }

    private fun addMessage(who: String, message: String) {
        val tv = TextView(this).apply {
            text = "$who\n$message"
            textSize = 14f
            setTextColor(if (who == "JARVIS") cyan else white)
            setPadding(12, 10, 12, 10)
            setBackgroundColor(Color.rgb(14, 26, 42))
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 5, 0, 5)
        chat.addView(tv, lp)
    }

    private fun sendPrompt() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        input.setText("")
        addMessage("SEN", prompt)
        val key = SecretStore.get(this)
        if (key.isNullOrBlank()) {
            addMessage("JARVIS", "Önce Ayarlar bölümünden Gemini API anahtarını eklemelisin.")
            return
        }
        addMessage("JARVIS", "İsteğin işleniyor...")
        executor.execute {
            val answer = try { askGemini(key, prompt) }
            catch (e: Exception) { "Bağlantı hatası: ${e.message ?: "Bilinmeyen hata"}" }
            runOnUiThread {
                val last = chat.getChildAt(chat.childCount - 1) as? TextView
                if (last != null && last.text.toString().startsWith("JARVIS\nİsteğin işleniyor")) {
                    chat.removeView(last)
                }
                addMessage("JARVIS", answer)
                speak(answer)
            }
        }
    }

    private fun askGemini(apiKey: String, prompt: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(
                JSONObject().put("text", "Sen JARVIS adlı Türkçe konuşan, kısa ve yardımcı bir kişisel asistansın. Yapamayacağın telefon işlemlerini yaptığını iddia etme. Kullanıcıdan onay gerektiren işlemlerde açıkça belirt.")
            )))
            .put("contents", JSONArray().put(JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .toString()
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        conn.disconnect()
        if (code !in 200..299) {
            val msg = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
            throw Exception("Gemini HTTP $code: ${msg ?: response.take(250)}")
        }
        val json = JSONObject(response)
        return json.optJSONArray("candidates")
            ?.optJSONObject(0)?.optJSONObject("content")
            ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
            ?: "Yanıt alınamadı."
    }

    private fun apiSettings() {
        val edit = EditText(this).apply {
            hint = "Gemini API key"
            setText(SecretStore.get(this@MainActivity) ?: "")
            inputType =  android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle("Gemini API ayarları")
            .setMessage("Anahtar cihazında Android Keystore ile şifrelenerek saklanır.")
            .setView(edit)
            .setPositiveButton("KAYDET") { _, _ ->
                val value = edit.text.toString().trim()
                if (value.isNotEmpty()) SecretStore.put(this, value)
                Toast.makeText(this, "API anahtarı kaydedildi.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("İPTAL", null)
            .show()
    }

    private fun startListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS dinliyor...")
        }
        try { startActivityForResult(intent, requestCodeSpeech) }
        catch (_: Exception) { addMessage("JARVIS", "Bu cihazda konuşma tanıma servisi bulunamadı.") }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCodeSpeech && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                input.setText(spoken)
                sendPrompt()
            }
        }
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text.take(2500), TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("tr", "TR")
    }

    private fun setAlarm() {
        val edit = EditText(this).apply {
            hint = "Saat:dakika (ör. 07:30)"
            setText("07:30")
        }
        AlertDialog.Builder(this)
            .setTitle("Alarm kur")
            .setMessage("Alarm saatini 24 saat biçiminde yaz.")
            .setView(edit)
            .setPositiveButton("ALARM UYGULAMASINI AÇ") { _, _ ->
                val parts = edit.text.toString().trim().split(":")
                val h = parts.getOrNull(0)?.toIntOrNull()
                val m = parts.getOrNull(1)?.toIntOrNull()
                if (h == null || m == null || h !in 0..23 || m !in 0..59) {
                    Toast.makeText(this, "Saat biçimi geçersiz.", Toast.LENGTH_SHORT).show()
                } else {
                    val i = Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, h)
                        .putExtra(AlarmClock.EXTRA_MINUTES, m)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS alarmı")
                    if (i.resolveActivity(packageManager) != null) startActivity(i)
                    else Toast.makeText(this, "Alarm uygulaması bulunamadı.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("İPTAL", null)
            .show()
    }

    private fun webSearch() {
        val q = input.text.toString().trim()
        if (q.isEmpty()) {
            input.hint = "Önce aramak istediğin şeyi yaz..."
            return
        }
        startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", q))
    }

    private fun shareToInstagram() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) {
            addMessage("JARVIS", "Instagram paylaşımı için önce mesaj metnini yaz.")
            return
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            setPackage("com.instagram.android")
        }
        try {
            startActivity(send)
            addMessage("JARVIS", "Instagram paylaşım ekranı açıldı. Alıcıyı seçip gönderimi sen onaylamalısın.")
        } catch (_: Exception) {
            val chooser = Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }, "Paylaş")
            startActivity(chooser)
            addMessage("JARVIS", "Instagram açılamadı; paylaşım menüsü açıldı.")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        executor.shutdown()
        super.onDestroy()
    }
}
