# J.A.R.V.I.S. Android

Türkçe arayüzlü, Gemini API kullanan başlangıç Android asistanı.

## Özellikler
- Gemini 2.5 Flash ile yazılı sohbet
- Android konuşma tanıma ile Türkçe sesli komut girişi
- Android TextToSpeech ile sesli yanıt
- Android alarm uygulamasına alarm kurma isteği gönderme
- Web araması başlatma
- Instagram paylaşım ekranına metin aktarma
- Gemini API anahtarını Android Keystore tabanlı AES-GCM ile cihazda şifreli saklama

## Önemli sınırlar
- Instagram'a kişisel hesap üzerinden arka planda, kullanıcı onayı olmadan otomatik DM gönderme özelliği yoktur. Instagram uygulamasının paylaşım ekranı açılır; alıcıyı seçip gönderimi kullanıcı tamamlar. Resmî Instagram Messaging API, uygun profesyonel hesaplar ve Meta izinleri gerektirir.
- Alarm, Android'in saat uygulamasına devredilir; cihazda desteklenen bir alarm uygulaması bulunmalıdır.
- Sesin karakteri cihazdaki Türkçe TTS motoruna bağlıdır. Filmdeki JARVIS sesinin birebir kopyası değildir.
- Gemini API anahtarı uygulamada cihaz üzerinde şifreli saklanır. Bu, kişisel kullanım için koruma sağlar; dağıtılan uygulamalarda anahtarları merkezi bir backend üzerinden yönetmek daha güvenlidir.
- Ses tanıma Android'in tanıma servisini kullanabilir; kullanılabilirlik ve ağ gereksinimi cihaza göre değişir.

## GitHub Actions ile APK
1. ZIP'i çıkarıp içeriğini bir GitHub deposuna yükle.
2. `.github/workflows/build.yml` dosyasının depoda bulunduğunu doğrula.
3. GitHub'da **Actions** sekmesini aç.
4. **Build JARVIS APK** iş akışını çalıştır veya `main` dalına push yap.
5. Tamamlanınca `JARVIS-debug-apk` adlı artifact'i indir.

## Android Studio
Projeyi Android Studio ile aç. JDK 17 ve Android SDK 35 kurulu olmalı. Gradle senkronizasyonundan sonra `app` yapılandırmasını çalıştırabilir veya `assembleDebug` görevini kullanabilirsin.

## İlk açılış
Uygulamada **API AYARLARI** bölümüne gir, Google AI Studio'dan aldığın Gemini API anahtarını kaydet. Ardından mesaj yaz veya **KONUŞ** düğmesini kullan.
